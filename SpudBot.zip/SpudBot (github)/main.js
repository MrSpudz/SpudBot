function Booting() {

    console.log('\x1b[31m', 'Booting');
}
function Connecting_to_server() {

    console.log('\x1b[31m', 'Connecting to servers');
}
function Logging_in() {

    console.log('\x1b[33m', 'Logging in');
}
function Ready() {

    console.log('\x1b[32m', 'Ready!');
}
function Prefix() {

    console.log(' Command prefix is', prefix)
}

const { WSAESOCKTNOSUPPORT } = require('constants');
const Discord = require('discord.js');

const client = new Discord.Client({
    allowedMentions: {
        parse: ['users', 'roles'],
        repliedUser: true,
    },
    intents: [
        "GUILDS",
        "GUILD_MESSAGES",
        "GUILD_PRESENCES",
        "GUILD_MEMBERS",
        "GUILD_MESSAGE_REACTIONS",
    ],
});

const prefix = '~'; //Sets the command prefix

const fs = require('fs');
const path = require('path');

client.commands = new Discord.Collection();

const commandFiles = fs.readdirSync('./commands/').filter(file => file.endsWith('.js')) //Checks that the files end with .js
for (const file of commandFiles) {
    const command = require(`./commands/${file}`);

    client.commands.set(command.name, command);
}

client.once('ready', () => {

    Booting();

    setTimeout(Logging_in, 100) //Waits 0.1 seconds before sending the Logging in" message to console

    setTimeout(Connecting_to_server, 700) //Waits 0.6 seconds before sending the "Connecting to servers" message to console

    setTimeout(Ready, 1500) //Waits 0.7 seconds before sending the "Ready" message to console

    setTimeout(Prefix, 1600) //Waits 0.8 seconds before sending the command prefix to console


    client.user.setActivity('with ~help', { type: 'PLAYING' }); //Sets the bots status
});

client.on('guildMemberAdd', guildMember => {

    guildMember.guild.channels.cache.get('866080133265358889').send(`Welcome <@${guildMember.user.id}> to the server. Make sure to check out the rules!`); //Sends a welcom message
})

client.on('testservers', () => {
    new WOKCommands(client, {
        commandsDir: path.join(__dirname, 'commands'),
        testServers: ['866074482346819594'],
    })
})

client.on('messageCreate', async message => {
    if (!message.content.startsWith(prefix) || message.author.bot) return;

    const args = message.content.slice(prefix.length).split(/ +/);
    const command = args.shift().toLowerCase(); //Makes sure the command is lowercase

    if (command === 'ping') {
        client.commands.get('ping').execute(message, args); //Latency command

    } else if (command == 'youtube') {
        client.commands.get('youtube').execute(message, args, Discord); //Sends My YT link

    } else if (command == 'kerbal') {
        client.commands.get('kerbal').execute(message, args); //Kerbal and KSP definition command

    } else if (command == 'bo') {
        client.commands.get('bo').execute(message, args); //Jeff Who?

    } else if (command == 'spacex') {
        client.commands.get('spacex').execute(message, args); //HEHE WATER TOWER GO FLY FLY BOOM BOOM!

    } else if (command == 'cookie') {
        client.commands.get('cookie').execute(message, args); //cookie :)

    } else if (command == 'help') {
        client.commands.get('help').execute(message, args, Discord);

    } else if (command == 'kick') {
        client.commands.get('kick').execute(client, message, args, Discord);

    } else if (command == 'ban') {
        client.commands.get('ban').execute(client, message, args, Discord);

    } else if (command == 'unban') {
        client.commands.get('unban').execute(client, message, args, Discord);

    } else if (command == 'pop') {
        client.commands.get('pop').execute(message, args, Discord);

    }
})

client.login('<TOKEN>'); //Logs the bot into the account
