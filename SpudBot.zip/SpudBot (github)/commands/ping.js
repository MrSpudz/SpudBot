const { Client } = require("discord.js");
const { execute } = require("./youtube");

module.exports = {
    name: 'ping',
    description: 'Pong!',
    execute(message, args) {
        message.channel.send('Pinging...').then(async (msg) => {
            msg.delete()
            message.channel.send(`🏓 Your ping is ${msg.createdTimestamp - message.createdTimestamp}ms. API Latency is ${Math.round(message.client.ws.ping)}ms`); //Calculates latency
        })
    }
}