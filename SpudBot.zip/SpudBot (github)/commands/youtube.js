module.exports = {
    name: 'youtube',
    description: "Sub to MrSpudz",
    execute(message, args, Discord) {
        const YouBed = new Discord.MessageEmbed() //Creates a new embed
            .setColor('#d40000')
            .setTitle('MrSpudz Youtube Channel')
            .setURL('https://www.youtube.com/channel/UCcCPq9nltYoe1jEOW_KawIA')
            .setDescription('Go sub to him.')
            .setThumbnail('https://i.imgur.com/eHGoa0T.png')
            .setTimestamp()

        message.channel.send({ embeds: [YouBed] });
    }
}
