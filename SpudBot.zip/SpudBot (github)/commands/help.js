module.exports = {
    name: 'help',
    description: "commands",
    execute(message, args, Discord) {
        const helpBed = new Discord.MessageEmbed() //Creates a new embed
            .setColor('#18c900')
            .setTitle('SpudBot Commands')
            .addFields(
                { name: '~ping', value: 'Tells you how bad your internet is', inline: true },
                { name: '~youtube', value: 'My creator\'s YouTube channel', inline: true },
                { name: '~kerbal', value: 'What is a "Kerbal" you may ask. Now you know!', inline: true },
                { name: '~cookie', value: ':cookie:', inline: true },
                { name: '~bo', value: 'Jeff Who?', inline: true },
                { name: '~spacex', value: 'HEHE FLYING WATER TOWER GO BOOM!', inline: true },
                { name: '~help', value: 'Do I really need to explain this.', inline: true },
                { name: '~ban', value: 'Ban very bad people.', inline: true },
                { name: '~kick', value: 'Kick bad people.', inline: true },
                { name: '~unban', value: 'Unban bad people that you want back for some reason.', inline: true },
                { name: '~pop', value: 'Do you like bubblewrap? NOW YOU CAN DO IT IN DISCORD!.', inline: true },
            )
            .setTimestamp()
            .setAuthor(message.author.tag, message.author.displayAvatarURL({ dynamic: true }))
            .setImage('https://cdn.riddle.com/embeds/v2/images/q_80,c_fill,w_960,h_540/ae0/ae040ac0d4d19bca6bb8a0899f3ed5c8.jpg')

        message.channel.send({ embeds: [helpBed] });
    }
}
