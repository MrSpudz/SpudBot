module.exports = {
    name: 'kerbal',
    description: 'A frog that goes to space!',
    execute(message, args) {
        message.channel.send('Kerbal Space Program is a space flight simulation video game developed by Mexican developer Squad and published by Private Division for Microsoft Windows, macOS, Linux, PlayStation 4, and Xbox One, In the game, players direct a nascent space program, staffed and crewed by green humanoid aliens known as "Kerbals". See image below for what they look like. :arrow_down:')
        message.channel.send('https://i.imgur.com/oPyO3CJ.png') //Sends an image of Jebediah Kerman
    }
}