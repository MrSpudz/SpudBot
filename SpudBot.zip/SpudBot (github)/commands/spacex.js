module.exports = {
    name: 'spacex',
    description: 'hehe tin can go brrrrrr',
    execute(message, args) {
        message.channel.send('Space Exploration Technologies Corp. is an American aerospace manufacturer, space transportation services and communications corporation headquartered in Hawthorne, California. SpaceX was founded in 2002 by Elon Musk with the goal of reducing space transportation costs to enable the colonization of Mars.')
        message.channel.send('https://www.pngkit.com/png/full/140-1407253_spacex-logo-space-exploration-technologies-logo.png') //Sends an image of the SpaceX logo
    }
}