module.exports = {
    name: 'bo',
    description: 'Jeff who?',
    execute(message, args) {
        message.channel.send('Blue Origin, LLC is an American privately funded aerospace manufacturer and sub-orbital spaceflight services company headquartered in Kent, Washington.')
        message.channel.send('https://seeklogo.com/images/B/blue-origin-logo-5D6380B50D-seeklogo.com.png') //Sends an image of the BO logo
    }
}