module.exports = {
    name: 'pop',
    description: "mmmm bubble wrap",
    execute(message, args, Discord) {
        const popBed = new Discord.MessageEmbed() //Creates a new embed
            .setColor('#18c900')
            .setTitle('Pop to your hearts content :)')
            .addFields(
                { name: '_ _', value: '||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||||POP||' },
                { name: '_ _', value: `Contributed by <@345874719045713932>`}
            )

        message.channel.send({ embeds: [popBed] });
    }
}
