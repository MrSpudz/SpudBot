module.exports = {
    name: 'cookie',
    description: 'yum',
    execute(message, args) {
        message.channel.send(':cookie:')
    }
}